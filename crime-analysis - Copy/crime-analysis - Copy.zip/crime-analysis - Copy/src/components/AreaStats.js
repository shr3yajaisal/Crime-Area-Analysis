import React from 'react';

function AreaStats() {
  return (
    <div className="area-stats">
      <div className="stat total-crimes">
        <h4>Total Crimes</h4>
        <div className="value">432</div>
        <div className="positive">-12% from last week</div>
      </div>
      <div className="stat safety-meter">
        <h4>Safety meter</h4>
        <div className="value danger">2</div>
        <div className="desc">This area is unsafe for you.</div>
      </div>
      <div className="stat sos">
        <h4>SOS received today.</h4>
        <div className="value critical">100</div>
        <div className="desc">Critical Region</div>
      </div>
    </div>
  );
}

export default AreaStats; 